# chrome-switcher

## Overview


## Usage


## Installation

The easiest way to install this program is using pip.

### Windows

In the console, type ``

### macOS

In the console, type ``

### Linux

This program has not been tested on Linux.
